"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SQLITE_OPEN_PRIVATECACHE = exports.SQLITE_OPEN_SHAREDCACHE = exports.SQLITE_OPEN_FULLMUTEX = exports.SQLITE_OPEN_NOMUTEX = exports.SQLITE_OPEN_MEMORY = exports.SQLITE_OPEN_URI = exports.SQLITE_OPEN_CREATE = exports.SQLITE_OPEN_READWRITE = exports.SQLITE_OPEN_READONLY = exports.SQLITE_DONE = exports.SQLITE_ROW = exports.SQLITE_WARNING = exports.SQLITE_NOTICE = exports.SQLITE_NOTADB = exports.SQLITE_RANGE = exports.SQLITE_FORMAT = exports.SQLITE_AUTH = exports.SQLITE_NOLFS = exports.SQLITE_MISUSE = exports.SQLITE_MISMATCH = exports.SQLITE_CONSTRAINT = exports.SQLITE_TOOBIG = exports.SQLITE_SCHEMA = exports.SQLITE_EMPTY = exports.SQLITE_PROTOCOL = exports.SQLITE_CANTOPEN = exports.SQLITE_FULL = exports.SQLITE_NOTFOUND = exports.SQLITE_CORRUPT = exports.SQLITE_IOERR = exports.SQLITE_INTERRUPT = exports.SQLITE_READONLY = exports.SQLITE_NOMEM = exports.SQLITE_LOCKED = exports.SQLITE_BUSY = exports.SQLITE_ABORT = exports.SQLITE_PERM = exports.SQLITE_INTERNAL = exports.SQLITE_ERROR = exports.SQLITE_OK = exports.PreparedStatement = exports.Transaction = exports.ReadTransaction = exports.SQLiteValue = exports.SQLiteRow = exports.SQLiteParams = exports.SQLiteError = exports.SQLiteArrayResult = exports.RuntimeInfo = exports.DatabaseOptions = void 0;
exports.SQLITE_NULL = exports.SQLITE_BLOB = exports.SQLITE_TEXT = exports.SQLITE_FLOAT = exports.SQLITE_INTEGER = exports.SQLITE_OPEN_NOFOLLOW = void 0;
exports.openDatabase = openDatabase;
const common_1 = require("./common");
Object.defineProperty(exports, "DatabaseOptions", { enumerable: true, get: function () { return common_1.DatabaseOptions; } });
Object.defineProperty(exports, "RuntimeInfo", { enumerable: true, get: function () { return common_1.RuntimeInfo; } });
Object.defineProperty(exports, "SQLiteArrayResult", { enumerable: true, get: function () { return common_1.SQLiteArrayResult; } });
Object.defineProperty(exports, "SQLiteError", { enumerable: true, get: function () { return common_1.SQLiteError; } });
Object.defineProperty(exports, "SQLiteParams", { enumerable: true, get: function () { return common_1.SQLiteParams; } });
Object.defineProperty(exports, "SQLiteRow", { enumerable: true, get: function () { return common_1.SQLiteRow; } });
Object.defineProperty(exports, "SQLiteValue", { enumerable: true, get: function () { return common_1.SQLiteValue; } });
Object.defineProperty(exports, "Transaction", { enumerable: true, get: function () { return common_1.Transaction; } });
Object.defineProperty(exports, "ReadTransaction", { enumerable: true, get: function () { return common_1.ReadTransaction; } });
Object.defineProperty(exports, "PreparedStatement", { enumerable: true, get: function () { return common_1.PreparedStatement; } });
var common_2 = require("./common");
Object.defineProperty(exports, "SQLITE_OK", { enumerable: true, get: function () { return common_2.SQLITE_OK; } });
Object.defineProperty(exports, "SQLITE_ERROR", { enumerable: true, get: function () { return common_2.SQLITE_ERROR; } });
Object.defineProperty(exports, "SQLITE_INTERNAL", { enumerable: true, get: function () { return common_2.SQLITE_INTERNAL; } });
Object.defineProperty(exports, "SQLITE_PERM", { enumerable: true, get: function () { return common_2.SQLITE_PERM; } });
Object.defineProperty(exports, "SQLITE_ABORT", { enumerable: true, get: function () { return common_2.SQLITE_ABORT; } });
Object.defineProperty(exports, "SQLITE_BUSY", { enumerable: true, get: function () { return common_2.SQLITE_BUSY; } });
Object.defineProperty(exports, "SQLITE_LOCKED", { enumerable: true, get: function () { return common_2.SQLITE_LOCKED; } });
Object.defineProperty(exports, "SQLITE_NOMEM", { enumerable: true, get: function () { return common_2.SQLITE_NOMEM; } });
Object.defineProperty(exports, "SQLITE_READONLY", { enumerable: true, get: function () { return common_2.SQLITE_READONLY; } });
Object.defineProperty(exports, "SQLITE_INTERRUPT", { enumerable: true, get: function () { return common_2.SQLITE_INTERRUPT; } });
Object.defineProperty(exports, "SQLITE_IOERR", { enumerable: true, get: function () { return common_2.SQLITE_IOERR; } });
Object.defineProperty(exports, "SQLITE_CORRUPT", { enumerable: true, get: function () { return common_2.SQLITE_CORRUPT; } });
Object.defineProperty(exports, "SQLITE_NOTFOUND", { enumerable: true, get: function () { return common_2.SQLITE_NOTFOUND; } });
Object.defineProperty(exports, "SQLITE_FULL", { enumerable: true, get: function () { return common_2.SQLITE_FULL; } });
Object.defineProperty(exports, "SQLITE_CANTOPEN", { enumerable: true, get: function () { return common_2.SQLITE_CANTOPEN; } });
Object.defineProperty(exports, "SQLITE_PROTOCOL", { enumerable: true, get: function () { return common_2.SQLITE_PROTOCOL; } });
Object.defineProperty(exports, "SQLITE_EMPTY", { enumerable: true, get: function () { return common_2.SQLITE_EMPTY; } });
Object.defineProperty(exports, "SQLITE_SCHEMA", { enumerable: true, get: function () { return common_2.SQLITE_SCHEMA; } });
Object.defineProperty(exports, "SQLITE_TOOBIG", { enumerable: true, get: function () { return common_2.SQLITE_TOOBIG; } });
Object.defineProperty(exports, "SQLITE_CONSTRAINT", { enumerable: true, get: function () { return common_2.SQLITE_CONSTRAINT; } });
Object.defineProperty(exports, "SQLITE_MISMATCH", { enumerable: true, get: function () { return common_2.SQLITE_MISMATCH; } });
Object.defineProperty(exports, "SQLITE_MISUSE", { enumerable: true, get: function () { return common_2.SQLITE_MISUSE; } });
Object.defineProperty(exports, "SQLITE_NOLFS", { enumerable: true, get: function () { return common_2.SQLITE_NOLFS; } });
Object.defineProperty(exports, "SQLITE_AUTH", { enumerable: true, get: function () { return common_2.SQLITE_AUTH; } });
Object.defineProperty(exports, "SQLITE_FORMAT", { enumerable: true, get: function () { return common_2.SQLITE_FORMAT; } });
Object.defineProperty(exports, "SQLITE_RANGE", { enumerable: true, get: function () { return common_2.SQLITE_RANGE; } });
Object.defineProperty(exports, "SQLITE_NOTADB", { enumerable: true, get: function () { return common_2.SQLITE_NOTADB; } });
Object.defineProperty(exports, "SQLITE_NOTICE", { enumerable: true, get: function () { return common_2.SQLITE_NOTICE; } });
Object.defineProperty(exports, "SQLITE_WARNING", { enumerable: true, get: function () { return common_2.SQLITE_WARNING; } });
Object.defineProperty(exports, "SQLITE_ROW", { enumerable: true, get: function () { return common_2.SQLITE_ROW; } });
Object.defineProperty(exports, "SQLITE_DONE", { enumerable: true, get: function () { return common_2.SQLITE_DONE; } });
Object.defineProperty(exports, "SQLITE_OPEN_READONLY", { enumerable: true, get: function () { return common_2.SQLITE_OPEN_READONLY; } });
Object.defineProperty(exports, "SQLITE_OPEN_READWRITE", { enumerable: true, get: function () { return common_2.SQLITE_OPEN_READWRITE; } });
Object.defineProperty(exports, "SQLITE_OPEN_CREATE", { enumerable: true, get: function () { return common_2.SQLITE_OPEN_CREATE; } });
Object.defineProperty(exports, "SQLITE_OPEN_URI", { enumerable: true, get: function () { return common_2.SQLITE_OPEN_URI; } });
Object.defineProperty(exports, "SQLITE_OPEN_MEMORY", { enumerable: true, get: function () { return common_2.SQLITE_OPEN_MEMORY; } });
Object.defineProperty(exports, "SQLITE_OPEN_NOMUTEX", { enumerable: true, get: function () { return common_2.SQLITE_OPEN_NOMUTEX; } });
Object.defineProperty(exports, "SQLITE_OPEN_FULLMUTEX", { enumerable: true, get: function () { return common_2.SQLITE_OPEN_FULLMUTEX; } });
Object.defineProperty(exports, "SQLITE_OPEN_SHAREDCACHE", { enumerable: true, get: function () { return common_2.SQLITE_OPEN_SHAREDCACHE; } });
Object.defineProperty(exports, "SQLITE_OPEN_PRIVATECACHE", { enumerable: true, get: function () { return common_2.SQLITE_OPEN_PRIVATECACHE; } });
Object.defineProperty(exports, "SQLITE_OPEN_NOFOLLOW", { enumerable: true, get: function () { return common_2.SQLITE_OPEN_NOFOLLOW; } });
Object.defineProperty(exports, "SQLITE_INTEGER", { enumerable: true, get: function () { return common_2.SQLITE_INTEGER; } });
Object.defineProperty(exports, "SQLITE_FLOAT", { enumerable: true, get: function () { return common_2.SQLITE_FLOAT; } });
Object.defineProperty(exports, "SQLITE_TEXT", { enumerable: true, get: function () { return common_2.SQLITE_TEXT; } });
Object.defineProperty(exports, "SQLITE_BLOB", { enumerable: true, get: function () { return common_2.SQLITE_BLOB; } });
Object.defineProperty(exports, "SQLITE_NULL", { enumerable: true, get: function () { return common_2.SQLITE_NULL; } });
// Load native library.
// JNI_OnLoad in bridge.cpp calls DatabaseBinding::Init via v8::Isolate::GetCurrent(),
// so global.NSCSQLite is ready as soon as loadLibrary returns.
java.lang.System.loadLibrary('nscsqlite');
const NSCSQLite = global.NSCSQLite;
// The native layer rejects/throws plain Error objects with a `.code` number
// property.  Re-wrap them as SQLiteError so callers can use `instanceof`.
function rewrapNativeError(e) {
    if (e instanceof common_1.SQLiteError)
        throw e;
    if (e != null && typeof e === 'object' && typeof e.code === 'number') {
        throw new common_1.SQLiteError(e.message ?? String(e), e.code);
    }
    throw e;
}
// Transparent proxy around the raw native object that catches errors from every
// method call (both sync throws and promise rejections) and rewraps them.
function makeNativeProxy(native) {
    return new Proxy(native, {
        get(target, prop) {
            const val = target[prop];
            if (typeof val !== 'function')
                return val;
            return function (...args) {
                let result;
                try {
                    result = val.apply(target, args);
                }
                catch (e) {
                    rewrapNativeError(e);
                }
                if (result != null && typeof result.then === 'function') {
                    return result.catch(rewrapNativeError);
                }
                return result;
            };
        },
    });
}
class PreparedStatementImpl {
    constructor(_db, _stmtId) {
        this._db = _db;
        this._stmtId = _stmtId;
    }
    async execute(params) {
        await this._db.stepStatement(this._stmtId, params, 0);
    }
    async select(params) {
        return await this._db.stepStatement(this._stmtId, params, 1);
    }
    async selectArray(params) {
        return await this._db.stepStatement(this._stmtId, params, 2);
    }
    async get(params) {
        return await this._db.stepStatement(this._stmtId, params, 3);
    }
    async getArray(params) {
        return await this._db.stepStatement(this._stmtId, params, 4);
    }
    async finalize() {
        await this._db.finalizeStatement(this._stmtId);
    }
}
class ReadTransactionImpl {
    constructor(_db, _txId) {
        this._db = _db;
        this._txId = _txId;
    }
    async select(sql, params) {
        return await this._db.selectInTransaction(this._txId, sql, params, 1);
    }
    async selectArray(sql, params) {
        return await this._db.selectInTransaction(this._txId, sql, params, 2);
    }
    async get(sql, params) {
        const res = await this._db.selectInTransaction(this._txId, sql, params, 1);
        return res && res.length > 0 ? res[0] : undefined;
    }
    async getArray(sql, params) {
        const res = await this._db.selectInTransaction(this._txId, sql, params, 2);
        if (res && res.rows && res.rows.length > 0) {
            return { columns: res.columns, rows: [res.rows[0]] };
        }
        return { columns: res.columns, rows: [] };
    }
}
class TransactionImpl extends ReadTransactionImpl {
    constructor(db, txId) {
        super(db, txId);
    }
    async execute(sql, params) {
        await this._db.executeInTransaction(this._txId, sql, params);
    }
    async savepoint(fn) {
        const name = `_sp${TransactionImpl._savepointSeq++}`;
        await this._db.executeInTransaction(this._txId, `SAVEPOINT ${name}`);
        try {
            const result = await fn(this);
            await this._db.executeInTransaction(this._txId, `RELEASE SAVEPOINT ${name}`);
            return result;
        }
        catch (e) {
            await this._db.executeInTransaction(this._txId, `ROLLBACK TO SAVEPOINT ${name}`);
            await this._db.executeInTransaction(this._txId, `RELEASE SAVEPOINT ${name}`);
            throw e;
        }
    }
}
TransactionImpl._savepointSeq = 0;
class SQLiteDatabaseImpl {
    constructor(options) {
        this._isOpen = false;
        // Each sqlite3_open_v2(':memory:') call creates a new independent in-memory
        // database, so the writer, readers, and sync connections would each get their
        // own isolated database. Fix: translate ':memory:' to a named shared-cache URI
        // so all pool connections share a single in-memory database instance.
        // Requires SQLITE_OPEN_URI in the C++ layer (sqlite_connection.cpp).
        if (options.path === ':memory:') {
            const uid = `_nscmem_${Date.now()}_${Math.random().toString(36).slice(2)}`;
            options = { ...options, path: `file:${uid}?mode=memory&cache=shared` };
        }
        this._db = makeNativeProxy(new NSCSQLite(options.path, options));
        this._isOpen = true;
    }
    get isOpen() {
        return this._isOpen;
    }
    async execute(sql, params) {
        await this._db.execute(sql, params);
    }
    async select(sql, params) {
        return await this._db.select(sql, params);
    }
    async selectArray(sql, params) {
        return await this._db.selectArray(sql, params);
    }
    async get(sql, params) {
        return await this._db.get(sql, params);
    }
    async getArray(sql, params) {
        return await this._db.getArray(sql, params);
    }
    async transaction(fn) {
        const txId = await this.beginTransaction();
        try {
            const tx = new TransactionImpl(this._db, txId);
            const res = await fn(tx);
            await this.commitTransaction(txId);
            return res;
        }
        catch (e) {
            await this.rollbackTransaction(txId);
            throw e;
        }
    }
    async readTransaction(fn) {
        const txId = await this.beginTransaction('deferred');
        try {
            const tx = new ReadTransactionImpl(this._db, txId);
            const res = await fn(tx);
            await this.commitTransaction(txId);
            return res;
        }
        catch (e) {
            await this.rollbackTransaction(txId);
            throw e;
        }
    }
    async prepare(sql) {
        const stmtId = await this._db.prepare(sql);
        return new PreparedStatementImpl(this._db, stmtId);
    }
    executeSync(sql, params) {
        this._db.executeSync(sql, params);
    }
    selectSync(sql, params) {
        return this._db.selectSync(sql, params);
    }
    selectArraySync(sql, params) {
        return this._db.selectArraySync(sql, params);
    }
    getSync(sql, params) {
        return this._db.getSync(sql, params);
    }
    getArraySync(sql, params) {
        return this._db.getArraySync(sql, params);
    }
    async beginTransaction(behavior) {
        return await this._db.beginTransaction(behavior);
    }
    async executeInTransaction(txId, sql, params) {
        await this._db.executeInTransaction(txId, sql, params);
    }
    async selectInTransaction(txId, sql, params) {
        return await this._db.selectInTransaction(txId, sql, params, 1);
    }
    async selectArrayInTransaction(txId, sql, params) {
        return await this._db.selectInTransaction(txId, sql, params, 2);
    }
    async commitTransaction(txId) {
        await this._db.commitTransaction(txId);
    }
    async rollbackTransaction(txId) {
        await this._db.rollbackTransaction(txId);
    }
    getRuntimeInfo() {
        return this._db.getRuntimeInfo();
    }
    async close() {
        if (this._isOpen) {
            await this._db.close();
            this._isOpen = false;
        }
    }
}
function openDatabase(options) {
    return new SQLiteDatabaseImpl(options);
}
