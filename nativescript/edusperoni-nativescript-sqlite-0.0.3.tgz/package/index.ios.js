"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RuntimeInfo = exports.SQLiteValue = exports.SQLiteRow = exports.SQLiteParams = exports.SQLiteError = exports.SQLiteArrayResult = exports.DatabaseOptions = void 0;
exports.openDatabase = openDatabase;
const common_1 = require("./common");
Object.defineProperty(exports, "DatabaseOptions", { enumerable: true, get: function () { return common_1.DatabaseOptions; } });
Object.defineProperty(exports, "RuntimeInfo", { enumerable: true, get: function () { return common_1.RuntimeInfo; } });
Object.defineProperty(exports, "SQLiteArrayResult", { enumerable: true, get: function () { return common_1.SQLiteArrayResult; } });
Object.defineProperty(exports, "SQLiteError", { enumerable: true, get: function () { return common_1.SQLiteError; } });
Object.defineProperty(exports, "SQLiteParams", { enumerable: true, get: function () { return common_1.SQLiteParams; } });
Object.defineProperty(exports, "SQLiteRow", { enumerable: true, get: function () { return common_1.SQLiteRow; } });
Object.defineProperty(exports, "SQLiteValue", { enumerable: true, get: function () { return common_1.SQLiteValue; } });
__exportStar(require("./common"), exports);
function toNSError(error) {
    const extCode = error.userInfo?.objectForKey?.('extendedCode');
    return new common_1.SQLiteError(error.localizedDescription, error.code, extCode ?? error.code);
}
function marshalParams(params) {
    if (!params)
        return NSArray.new();
    if (Array.isArray(params)) {
        return NSArray.arrayWithArray(params.map((v) => {
            if (v === null || v === undefined)
                return NSNull.null();
            if (typeof v === 'boolean')
                return NSNumber.numberWithBool(v);
            if (typeof v === 'number')
                return NSNumber.numberWithDouble(v);
            if (typeof v === 'string')
                return v;
            if (v instanceof ArrayBuffer)
                return NSData.dataWithData(v);
            return NSNull.null();
        }));
    }
    const dict = NSMutableDictionary.new();
    for (const key of Object.keys(params)) {
        const v = params[key];
        if (v === null || v === undefined) {
            dict.setObjectForKey(NSNull.null(), key);
        }
        else if (typeof v === 'boolean') {
            dict.setObjectForKey(NSNumber.numberWithBool(v), key);
        }
        else if (typeof v === 'number') {
            dict.setObjectForKey(NSNumber.numberWithDouble(v), key);
        }
        else if (typeof v === 'string') {
            dict.setObjectForKey(v, key);
        }
        else if (v instanceof ArrayBuffer) {
            dict.setObjectForKey(NSData.dataWithData(v), key);
        }
        else {
            dict.setObjectForKey(NSNull.null(), key);
        }
    }
    return NSArray.arrayWithObject(dict);
}
function parseSelectResult(json, blobs) {
    const rows = JSON.parse(json);
    if (blobs && blobs.count > 0) {
        hydrateBlobs(rows, blobs);
    }
    return rows;
}
function hydrateBlobs(rows, blobs) {
    for (const row of rows) {
        for (const key of Object.keys(row)) {
            const val = row[key];
            if (val && typeof val === 'object' && '__blob__' in val) {
                const nsData = blobs.objectAtIndex(val.__blob__);
                row[key] = interop.bufferFromData(nsData);
            }
        }
    }
}
function parseArrayResult(json, blobs) {
    const result = JSON.parse(json);
    if (blobs && blobs.count > 0) {
        for (const row of result.rows) {
            for (let i = 0; i < row.length; i++) {
                const val = row[i];
                if (val && typeof val === 'object' && '__blob__' in val) {
                    const nsData = blobs.objectAtIndex(val.__blob__);
                    row[i] = interop.bufferFromData(nsData);
                }
            }
        }
    }
    return result;
}
class WriteTxImpl {
    constructor(native, txId, _savepointCounter) {
        this.native = native;
        this.txId = txId;
        this._savepointCounter = _savepointCounter;
    }
    execute(sql, params) {
        return new Promise((resolve, reject) => {
            this.native.executeInTransactionSqlParamsCompletion(this.txId, sql, marshalParams(params), (error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve();
                }
            });
        });
    }
    select(sql, params) {
        return new Promise((resolve, reject) => {
            this.native.selectInTransactionSqlParamsCompletion(this.txId, sql, marshalParams(params), (json, blobs, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(parseSelectResult(json, blobs));
                }
            });
        });
    }
    selectArray(sql, params) {
        return new Promise((resolve, reject) => {
            this.native.selectArrayInTransactionSqlParamsCompletion(this.txId, sql, marshalParams(params), (json, blobs, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(parseArrayResult(json, blobs));
                }
            });
        });
    }
    get(sql, params) {
        return this.select(sql, params).then((rows) => rows[0]);
    }
    getArray(sql, params) {
        return this.selectArray(sql, params).then((r) => ({ columns: r.columns, rows: r.rows.slice(0, 1) }));
    }
    async savepoint(fn) {
        const name = `sp_${this._savepointCounter.value++}`;
        await this.execute(`SAVEPOINT ${name}`);
        try {
            const result = await fn(this);
            await this.execute(`RELEASE ${name}`);
            return result;
        }
        catch (e) {
            await this.execute(`ROLLBACK TO ${name}`);
            throw e;
        }
    }
}
class ReadTxImpl {
    constructor(native, txId) {
        this.native = native;
        this.txId = txId;
    }
    select(sql, params) {
        return new Promise((resolve, reject) => {
            this.native.selectInReadTransactionSqlParamsCompletion(this.txId, sql, marshalParams(params), (json, blobs, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(parseSelectResult(json, blobs));
                }
            });
        });
    }
    selectArray(sql, params) {
        return new Promise((resolve, reject) => {
            this.native.selectArrayInReadTransactionSqlParamsCompletion(this.txId, sql, marshalParams(params), (json, blobs, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(parseArrayResult(json, blobs));
                }
            });
        });
    }
    get(sql, params) {
        return this.select(sql, params).then((rows) => rows[0]);
    }
    getArray(sql, params) {
        return this.selectArray(sql, params).then((r) => ({ columns: r.columns, rows: r.rows.slice(0, 1) }));
    }
}
class PreparedStatementImpl {
    constructor(native, stmtId) {
        this.native = native;
        this.stmtId = stmtId;
    }
    execute(params) {
        return new Promise((resolve, reject) => {
            this.native.executePreparedParamsCompletion(this.stmtId, marshalParams(params), (error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve();
                }
            });
        });
    }
    select(params) {
        return new Promise((resolve, reject) => {
            this.native.selectPreparedParamsCompletion(this.stmtId, marshalParams(params), (json, blobs, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(parseSelectResult(json, blobs));
                }
            });
        });
    }
    selectArray(params) {
        return new Promise((resolve, reject) => {
            this.native.selectArrayPreparedParamsCompletion(this.stmtId, marshalParams(params), (json, blobs, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(parseArrayResult(json, blobs));
                }
            });
        });
    }
    get(params) {
        return this.select(params).then((rows) => rows[0]);
    }
    getArray(params) {
        return this.selectArray(params).then((r) => ({ columns: r.columns, rows: r.rows.slice(0, 1) }));
    }
    finalize() {
        return new Promise((resolve, reject) => {
            this.native.finalizePreparedCompletion(this.stmtId, (error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve();
                }
            });
        });
    }
}
class SQLiteDatabaseImpl {
    constructor(native) {
        this.native = native;
    }
    get isOpen() {
        return this.native.isOpen;
    }
    execute(sql, params) {
        return new Promise((resolve, reject) => {
            this.native.executeParamsCompletion(sql, marshalParams(params), (error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve();
                }
            });
        });
    }
    select(sql, params) {
        return new Promise((resolve, reject) => {
            this.native.selectParamsCompletion(sql, marshalParams(params), (json, blobs, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(parseSelectResult(json, blobs));
                }
            });
        });
    }
    selectArray(sql, params) {
        return new Promise((resolve, reject) => {
            this.native.selectArrayParamsCompletion(sql, marshalParams(params), (json, blobs, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(parseArrayResult(json, blobs));
                }
            });
        });
    }
    get(sql, params) {
        return this.select(sql, params).then((rows) => rows[0]);
    }
    getArray(sql, params) {
        return this.selectArray(sql, params).then((r) => ({ columns: r.columns, rows: r.rows.slice(0, 1) }));
    }
    async transaction(fn) {
        const txId = await new Promise((resolve, reject) => {
            this.native.beginTransactionCompletion('deferred', (id, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(id);
                }
            });
        });
        const tx = new WriteTxImpl(this.native, txId, { value: 0 });
        try {
            const result = await fn(tx);
            await new Promise((resolve, reject) => {
                this.native.commitTransactionCompletion(txId, (error) => {
                    if (error) {
                        reject(toNSError(error));
                    }
                    else {
                        resolve();
                    }
                });
            });
            return result;
        }
        catch (e) {
            await new Promise((resolve) => {
                this.native.rollbackTransactionCompletion(txId, () => resolve());
            });
            throw e;
        }
    }
    async readTransaction(fn) {
        const txId = await new Promise((resolve, reject) => {
            this.native.beginReadTransaction((id, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(id);
                }
            });
        });
        const tx = new ReadTxImpl(this.native, txId);
        try {
            const result = await fn(tx);
            await new Promise((resolve) => {
                this.native.endReadTransactionCompletion(txId, () => resolve());
            });
            return result;
        }
        catch (e) {
            await new Promise((resolve) => {
                this.native.endReadTransactionCompletion(txId, () => resolve());
            });
            throw e;
        }
    }
    prepare(sql) {
        return new Promise((resolve, reject) => {
            this.native.prepareCompletion(sql, (stmtId, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(new PreparedStatementImpl(this.native, stmtId));
                }
            });
        });
    }
    executeSync(sql, params) {
        const ok = this.native.executeSyncParamsError(sql, marshalParams(params));
        if (!ok) {
            throw new common_1.SQLiteError('executeSync failed', -1);
        }
    }
    selectSync(sql, params) {
        const json = this.native.selectSyncParamsError(sql, marshalParams(params));
        if (!json) {
            throw new common_1.SQLiteError('selectSync failed', -1);
        }
        return JSON.parse(json);
    }
    selectArraySync(sql, params) {
        const json = this.native.selectArraySyncParamsError(sql, marshalParams(params));
        if (!json) {
            throw new common_1.SQLiteError('selectArraySync failed', -1);
        }
        return JSON.parse(json);
    }
    getSync(sql, params) {
        return this.selectSync(sql, params)[0];
    }
    getArraySync(sql, params) {
        return this.selectArraySync(sql, params);
    }
    // Low-level transaction control for driver integrations
    beginTransaction(behavior) {
        return new Promise((resolve, reject) => {
            this.native.beginTransactionCompletion(behavior ?? 'deferred', (id, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(id);
                }
            });
        });
    }
    executeInTransaction(txId, sql, params) {
        return new Promise((resolve, reject) => {
            this.native.executeInTransactionSqlParamsCompletion(txId, sql, marshalParams(params), (error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve();
                }
            });
        });
    }
    selectInTransaction(txId, sql, params) {
        return new Promise((resolve, reject) => {
            this.native.selectInTransactionSqlParamsCompletion(txId, sql, marshalParams(params), (json, blobs, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(parseSelectResult(json, blobs));
                }
            });
        });
    }
    selectArrayInTransaction(txId, sql, params) {
        return new Promise((resolve, reject) => {
            this.native.selectArrayInTransactionSqlParamsCompletion(txId, sql, marshalParams(params), (json, blobs, error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve(parseArrayResult(json, blobs));
                }
            });
        });
    }
    commitTransaction(txId) {
        return new Promise((resolve, reject) => {
            this.native.commitTransactionCompletion(txId, (error) => {
                if (error) {
                    reject(toNSError(error));
                }
                else {
                    resolve();
                }
            });
        });
    }
    rollbackTransaction(txId) {
        return new Promise((resolve) => {
            this.native.rollbackTransactionCompletion(txId, () => resolve());
        });
    }
    getRuntimeInfo() {
        return {
            version: '3.x',
            sourceId: 'ios-stub',
            compileOptions: [],
        };
    }
    close() {
        return new Promise((resolve) => {
            this.native.closeWithCompletion(() => {
                resolve();
            });
        });
    }
}
function openDatabase(options) {
    const native = NSSQLiteDatabase.openWithPathPoolSizeReadOnlyBusyTimeoutEncryptionKey(options.path, options.poolSize ?? 4, options.readOnly ?? false, options.busyTimeout ?? 5000, options.encryptionKey ?? null);
    if (!native) {
        throw new common_1.SQLiteError(`Failed to open database: ${options.path}`, -1);
    }
    return new SQLiteDatabaseImpl(native);
}
